package TEST_1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;

import javax.swing.AbstractCellEditor;
import javax.swing.DefaultCellEditor;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.text.Document;

import java.awt.*;

public class EasyMoneyFrame extends JFrame {
    public static String defaultpath = "C:\\Users\\USER\\Desktop\\";
	
	private JTextField fundcode,fundfcode,fundname,gongName,gBdate,gEdate,dowpath,dowName,savePath,saveName,tiaojian,bdate,edate,faburi;
	private JTable table_all,table_com,table_fund;
	private JScrollPane scrollPane_1, scrollPane_2,scrollPane_3;
	private JComboBox choice;
	private JCheckBox code,fcode,name,date,f_name;

	/**
	 * Create the frame
	 */
//	String pdfsearch[] = { "��������", "��������" };

	
	private Object[][] getselect(List list) {
		Object[][] s = new Object[list.size()][4];
		for (int i = 0; i < list.size(); i++) {
			Pdf pdf = (Pdf) list.get(i);
			s[i][0] = pdf.getPdfName();
			s[i][1] = pdf.getPdfDownload();
			s[i][2] = pdf.getPdfDate();
			s[i][3] = new Boolean(false);
		}
		return s;
	}
	
	private Object[][] getselectC(List list){
		Object[][] s = new Object[list.size()][2];
		for(int i=0;i<list.size();i++){
			Company com = (Company) list.get(i);
			s[i][0] = com.getComId();
			s[i][1] = com.getComName();
		}
		return s;
	}
	
	private Object[][] getselectF(List list){
		Object[][] s = new Object[list.size()][3];
		for(int i=0;i<list.size();i++){
			Fund fund = (Fund) list.get(i);
			s[i][0] = fund.getfundCode();
			s[i][1] = fund.getFundName();
			s[i][2] = fund.getFundType();
		}
		return s;
	}
	
	private Object[][] getjiansuo(List list){
		Object[][] s = new Object[list.size()][2];
		for(int i=0;i<list.size();i++){
			Pdf pdf = (Pdf) list.get(i);
			s[i][0]=pdf.getPdfName();
			s[i][1]=pdf.getPdfDate();
		}
		return s;
	}


	public EasyMoneyFrame() {
		super();
		final BorderLayout borderLayout = new BorderLayout();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		borderLayout.setVgap(10);
		getContentPane().setLayout(borderLayout);
		this.setTitle("���������pdf��ѯ����v3.0                    author:VK");
        this.setPreferredSize(new Dimension(1000,800));
		setBounds(200, 200, 285, 194);
        
        pack();
		
        
        final JTabbedPane tabbedPane=new JTabbedPane();
        tabbedPane.setPreferredSize(new Dimension(0,50));
        getContentPane().add(tabbedPane);
        
        final JPanel panel_1 = new JPanel();
        panel_1.setLayout(new BorderLayout());
        tabbedPane.addTab("������ѯ", null,panel_1,null);
        
        final JPanel panel_1_1 = new JPanel();
        panel_1_1.setPreferredSize(new Dimension(0,50));
        panel_1_1.setBorder(new TitledBorder(null, "��ѡ���ѯ��Ŀ", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, null, null));
        panel_1.add(panel_1_1, BorderLayout.NORTH);
        
        code = new JCheckBox("������",true);
        fundcode = new JTextField();
        fundcode.setColumns(6);
        panel_1_1.add(code);
        panel_1_1.add(fundcode);
        
        name = new JCheckBox("����ؼ���",true);
        gongName = new JTextField();
        gongName.setColumns(15);
        panel_1_1.add(name);
        panel_1_1.add(gongName);
        
        date = new JCheckBox("��������",true);
        panel_1_1.add(date);
        
        final JLabel label_from = new JLabel();
        label_from.setText("From ");
        panel_1_1.add(label_from);
        
        gBdate = new JTextField();
        gBdate.setColumns(8);
        panel_1_1.add(gBdate);
        
        final JLabel label_to = new JLabel();
        label_to.setText("To");
        panel_1_1.add(label_to);
        
        gEdate = new JTextField();
        gEdate.setColumns(8);
        panel_1_1.add(gEdate);
        
        
        final JButton select = new JButton();
        select.setText("��ѯ");
        panel_1_1.add(select);
        
        select.addActionListener(new ActionListener(){
        	public void actionPerformed(ActionEvent arg0){
        		boolean b1,b2,b3;
        		b1=code.isSelected();
        		b2=name.isSelected();
        		b3=date.isSelected();
        		
        		if(b1==true&&b2==true&&b3==true){

        			String codes = fundcode.getText().trim();
            		String names = replaceSpace(gongName.getText().trim());
            		String Bdates = gBdate.getText().trim();
            		String Edates = gEdate.getText().trim();
            		List list = new ArrayList();
            		table_all = new JTable();
            		if (Edates!=null){
//            	        table_all=new JTable(gongModel(DAO.selectPdfAll(codes, names, Bdates, Edates)));
            			gongmodel(table_all,DAO.selectPdfAll(codes, names, Bdates,Edates));
            		}else{
            			table_all=new JTable(gongModel(DAO.selectPdfAll(codes, names, Bdates)));
            		}
            		AllColumnModel(table_all);
	        		table_all.addMouseListener(new TableListener());
	        		table_all.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
	        		scrollPane_1.setViewportView(table_all);
	        		
        		}else if(b1==true&&b2==true&&b3==false){

            		String codes = fundcode.getText().trim();
            		String names = replaceSpace(gongName.getText().trim());
            		List list = DAO.selectPdfCN(codes, names);
            		Object[][] results=getselect(list);
            		
            		table_all =new JTable(gongModel(list));
	        		
            		AllColumnModel(table_all);
            		
            		table_all.addMouseListener(new TableListener());
	        		table_all.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
	        		scrollPane_1.setViewportView(table_all);
        			
        			
        		}else if(b1==true&&b2==false&&b3==false){

            		String codes = fundcode.getText().trim();
            		List list = DAO.selectPdfCode(codes);
            		Object[][] results=getselect(list);
            		
            		table_all =new JTable(gongModel(list));
	        		
            		AllColumnModel(table_all);
            		
            		table_all.addMouseListener(new TableListener());
	        		table_all.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
	        		scrollPane_1.setViewportView(table_all);
	        		
        		}else if(b1==false&&b2==false&&b3==false){
        			JOptionPane.showMessageDialog(null, "�����ѡ��һ����ѯ������");
            					return;
        		}else if(b1==false&&b2==false&&b3==true){

        			String Bdates = gBdate.getText().trim();
            		String Edates = gEdate.getText().trim();
            		List list = new ArrayList();
            		if (Edates!=null){
            	        list = DAO.selectPdfDatequjian( Bdates, Edates);
            		}else{
            			list = DAO.selectPdfDate(Bdates);
            		}
            		
            		table_all =new JTable(gongModel(list));
	        		
            		AllColumnModel(table_all);
            		
            		table_all.addMouseListener(new TableListener());
	        		table_all.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
	        		scrollPane_1.setViewportView(table_all);
	        		
        		}else if(b1==false&&b2==true&&b3==false){
        			
        			String names = replaceSpace(gongName.getText().trim());
            		List list = DAO.selectPdfName(names);
            		
            		table_all =new JTable(gongModel(list));
	        		
            		AllColumnModel(table_all);
            		
            		table_all.addMouseListener(new TableListener());
	        		table_all.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
	        		scrollPane_1.setViewportView(table_all);
        			
        		}else if(b1==false&&b2==true&&b3==true){
        			
        			String names = replaceSpace(gongName.getText().trim());
            		String Bdates = gBdate.getText().trim();
            		String Edates = gEdate.getText().trim();
            		List list = new ArrayList();
            		if (Edates!=null){
            	        list = DAO.selectPdfND(names, Bdates, Edates);
            		}else{
            			list = DAO.selectPdfND(names, Bdates);
            		}
            		
            		table_all =new JTable(gongModel(list));
	        		
            		AllColumnModel(table_all);
            		
            		table_all.addMouseListener(new TableListener());
	        		table_all.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
	        		scrollPane_1.setViewportView(table_all);
	        		
        		}else if(b1==true&&b2==false&&b3==true){

        			String codes = fundcode.getText().trim();
            		String Bdates = gBdate.getText().trim();
            		String Edates = gEdate.getText().trim();
            		List list = new ArrayList();
            		if (Edates!=null){
            	        list = DAO.selectPdfCD(codes, Bdates, Edates);
            		}else{
            			list = DAO.selectPdfCD(codes, Bdates);
            		}
            		
            		table_all =new JTable(gongModel(list));
	        		
            		AllColumnModel(table_all);
            		
            		table_all.addMouseListener(new TableListener());
	        		table_all.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
	        		scrollPane_1.setViewportView(table_all);
        		}
        		    
    			}
        });
//        choice=new JComboBox();
//		String[] array={"������","��������ģ����ѯ","���淢�����","���淢������","���淢������"};
//		for(int i=0;i<array.length;i++){
//			choice.addItem(array[i]);
//			
//		}
//        
//		panel_1_1.add(choice);
//		
//        fundcode = new JTextField();
//        fundcode.setColumns(30);
//        fundcode.addKeyListener(new SearchListener());
//        panel_1_1.add(fundcode);
        
        final JPanel panel_1_2=new JPanel();
        panel_1_2.setBorder(new TitledBorder(null,"��ѯ�����ʾ",TitledBorder.DEFAULT_JUSTIFICATION,TitledBorder.DEFAULT_POSITION,null,null));
        panel_1.add(panel_1_2);
        
        scrollPane_1 = new JScrollPane();
        scrollPane_1.setPreferredSize(new Dimension(800,600));
        panel_1_2.add(scrollPane_1);
        

        
        final JPanel panel_2_1=new JPanel();
        panel_2_1.setPreferredSize(new Dimension(800,50));
        panel_1.add(panel_2_1,BorderLayout.SOUTH);
        final GridLayout gridLayout = new GridLayout(0, 6);
		gridLayout.setVgap(5);
		gridLayout.setHgap(5);
		panel_2_1.setLayout(gridLayout);
        
        
        final JLabel label_3 = new JLabel();
        label_3.setText("�������ƣ�");
        panel_2_1.add(label_3);
        
        dowName = new JTextField();
        dowName.setPreferredSize(new Dimension(20,50));
        panel_2_1.add(dowName);
        
        final JLabel label_4 = new JLabel();
        label_4.setText("�����ַ��");
        panel_2_1.add(label_4);
        
        dowpath = new JTextField();
        panel_2_1.add(dowpath);
        
        final JLabel label_5 = new JLabel();
        label_5.setText("����·����");
        panel_2_1.add(label_5);
        
        savePath = new JTextField();
        savePath.setText(defaultpath);
        panel_2_1.add(savePath);
        
//        final JLabel label_6 = new JLabel();
//        label_6.setText("��������");
//        panel_2_1.add(label_6);
//        
//        saveName = new JTextField();
//        panel_2_1.add(saveName);
        
        final JButton alldown = new JButton();
        alldown.setText("ȫ������");
        alldown.addActionListener(new AllDownAction());
        panel_2_1.add(alldown);
        
        final JButton dowload = new JButton();
        dowload.setText("����");
        dowload.addActionListener(new DownloadAction());
        panel_2_1.add(dowload);
        
//        final JButton select = new JButton();
//        select.setText("��ѯ");
//        panel_2_1.add(select);
//        
//        select.addActionListener(new ActionListener(){
//        	public void actionPerformed(ActionEvent arg0){
//
//        		    if (fundcode.getText().length()!=0){
//    					JOptionPane.showMessageDialog(null, "����Ҫ���ݻ����Ų�ѯ����������ȷ����λ������"+"\r\n"
//    				+"����Ҫ���ݻ��𹫸����Ʋ�ѯ��������Ҫ��ѯ�Ĺؼ��ּ���"+"\r\n"+"������ѯ�������������磺�������--2019    ��������--201902    ��������--20190210");
//    					return;
//    				}
//        		    
//    				String name=(String)choice.getSelectedItem();
//    				
//    				if(name.equals("������")){
//    				String [] select={"��������","������ҳ","����pdf","��������"};
//            		String code = fundcode.getText().trim();
//            		System.out.println("eeee");
//            		List list = DAO.selectPdfCode(code);
//            		System.out.println("dddd");
//            		Object[][] results=getselect(list);
//
//            		table_all = new JTable(results,select);
//            		table_all.addMouseListener(new TableListener());
//            		table_all.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
//            		scrollPane_1.setViewportView(table_all);
//    			  }
//    				else if(name.equals("��������ģ����ѯ")){
//    					String [] select={"��������","������ҳ","����pdf","��������"};
//    	        		String code = fundcode.getText().trim();
//    	        		List list = DAO.selectPdfName(code);
//    	        		Object[][] results=getselect(list);
//
//    	        		table_all = new JTable(results,select);
//    	        		table_all.addMouseListener(new TableListener());
//    	        		table_all.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
//    	        		scrollPane_1.setViewportView(table_all);
//    				}
//    				else if(name.contains("���淢��")){
//    					String [] select={"��������","������ҳ","����pdf","��������"};
//    	        		String code = fundcode.getText().trim();
//    	        		List list = DAO.selectPdfDate(code);
//    	        		Object[][] results=getselect(list);
//
//    	        		table_all = new JTable(results,select);
//    	        		table_all.addMouseListener(new TableListener());
//    	        		table_all.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
//    	        		scrollPane_1.setViewportView(table_all);
//    				}
//    			}
//        });
        
        final JButton exit = new JButton();
        exit.setText("�˳�");
        panel_2_1.add(exit);
        exit.addActionListener(new CloseActionListener());
//   -------------------------------------------------------
//   -------------------------------------------------------     
//      
//        
//        final JPanel panel_check_1 = new JPanel();
//        panel_check_1.setLayout(new BorderLayout());
//        tabbedPane.addTab("����ɸѡ��ѯ", null,panel_check_1,null);
//        
//        final JPanel panel_check_1_2=new JPanel();
//        panel_check_1_2.setBorder(new TitledBorder(null,"��ѯ�����ʾ",TitledBorder.DEFAULT_JUSTIFICATION,TitledBorder.DEFAULT_POSITION,null,null));
//        panel_check_1.add(panel_check_1_2);
//        
//        scrollPane_2 = new JScrollPane();
//        scrollPane_2.setPreferredSize(new Dimension(800,600));
//        panel_check_1_2.add(scrollPane_2);
//        
//        String[] jiansuo={"��������","��������"};
//		String code = fundcode.getText().trim();
//		List list = EasyMoneySearch.EasyMoneySearch(code);
//		Object[][] results=getjiansuo(list);
//		table_select = new JTable(results,jiansuo);
//		table_select.addMouseListener(new TableListener());
//		table_select.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
//		scrollPane_2.setViewportView(table_select);
//        
//        
//        
//        final JPanel panel_check_2_1=new JPanel();
//        panel_check_2_1.setPreferredSize(new Dimension(800,50));
//        panel_check_1.add(panel_check_2_1,BorderLayout.SOUTH);
//        final GridLayout gridLayout_check = new GridLayout(0, 6);
//		gridLayout_check.setVgap(5);
//		gridLayout_check.setHgap(5);
//		panel_check_2_1.setLayout(gridLayout_check);
//        
//        
//        final JLabel gonggaoming = new JLabel();
//        gonggaoming.setText("�������ƣ�");
//        panel_check_2_1.add(gonggaoming);
//        
//        dowName = new JTextField();
//        dowName.setPreferredSize(new Dimension(20,50));
//        panel_check_2_1.add(dowName);
//        
//        
//        final JButton mingchengcheck = new JButton();
//        mingchengcheck.setText("���Ƽ���");
//        mingchengcheck.addActionListener(new MingchengAction());
//        panel_check_2_1.add(mingchengcheck);
//        
//
//        final JLabel date = new JLabel();
//        date.setText("�������ڣ�");
//        panel_check_2_1.add(date);
//
//        faburi = new JTextField();
//        panel_check_2_1.add(date);
//        
//        final JButton datecheck = new JButton();
//        datecheck.setText("�������ڼ���");
//        datecheck.addActionListener(new DateAction());
//        panel_check_2_1.add(datecheck);
//    
//        
//        panel_check_2_1.add(alldown);        
//   -------------------------------------------------------- 
//        final JPanel panel_com = new JPanel();
//        tabbedPane.addTab("ȫ����˾", null,panel_com,null);
//        
//        scrollPane_2 = new JScrollPane();
//        panel_com.add(scrollPane_2);
//        
//        String [] com={"��˾���","��˾����"};
//		List list_com = DAO.selectCompany();
//		Object[][] coms=getselectC(list_com);
//
//		table_com = new JTable(coms,com);
//		
//		TableColumn col_1 = table_com.getColumnModel().getColumn(0);
//		TableColumn col_2 = table_com.getColumnModel().getColumn(1);
//		col_1.setPreferredWidth(200);
//		col_1.setMinWidth(50);
//		col_1.setMaxWidth(200);
//		col_2.setPreferredWidth(200);
//		col_2.setMinWidth(50);
//		col_2.setMaxWidth(200);
//		
//		table_com.addMouseListener(new TableListener());
//		table_com.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
//		scrollPane_2.setViewportView(table_com);
//	 --------------------------------------------------------	
		final JPanel panel_fund = new JPanel();
		tabbedPane.addTab("ȫ������",null,panel_fund,null);
		
		scrollPane_3 = new JScrollPane();
		scrollPane_3.setPreferredSize(new Dimension(450,600));
		panel_fund.add(scrollPane_3);
		
		final JPanel panel_fund_1 = new JPanel();
		panel_1_2.setBorder(new TitledBorder(null,"��ѯ������Ϣ",TitledBorder.DEFAULT_JUSTIFICATION,TitledBorder.DEFAULT_POSITION,null,null));
		panel_fund.add(panel_fund_1,BorderLayout.SOUTH);
		
		
		final JLabel f_code = new JLabel();
		f_code.setText("������Ҫ���ҵ�:");
		panel_fund_1.add(f_code);
		fcode = new JCheckBox("������",true);
		panel_fund_1.add(fcode);
		fundfcode = new JTextField();
		fundfcode.setColumns(20);
		panel_fund_1.add(fundfcode);
		
		f_name = new JCheckBox("��������",true);
		fundname = new JTextField();
		fundname.setColumns(20);;
		panel_fund_1.add(f_name);
		panel_fund_1.add(fundname);
		
		
		final JButton check = new JButton();
		check.setText("Check");
		check.addActionListener(new ActionListener(){
			public void actionPerformed(final ActionEvent e){
        		boolean b1,b2,b3;
        		b1=fcode.isSelected();
        		b2=f_name.isSelected();
        		
        		if(b1==true&&b2==true){
        			String codes = fundcode.getText().trim();
        			String names = fundname.getText().trim();
                    table_fund = new JTable(fundModel(DAO.selectFundCN(codes, names)));
                    fundCols(table_fund);
        		}else if(b1==true&&b2==false){
                    String codes = fundcode.getText().trim();
                    table_fund = new JTable(fundModel(DAO.selectFundCode(codes)));
                    fundCols(table_fund);
        		}else if(b1==false&&b2==true){
        			String names = fundname.getText().trim();
        			table_fund = new JTable(fundModel(DAO.selectFund(names)));
        			fundCols(table_fund);
        		}

			} 
		});
		
		final JButton checkAll = new JButton();
		checkAll.setText("��ѯȫ��");
		checkAll.addActionListener(new ActionListener(){
			public void actionPerformed(final ActionEvent e){
				table_fund = new JTable(fundModel(DAO.selectFund()));
				fundCols(table_fund);
		        table_fund.addMouseListener(new TableListener());
				table_fund.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
				scrollPane_3.setViewportView(table_fund);
			}
		});
		
		
		panel_fund_1.add(check);
		panel_fund_1.add(checkAll);
//	 --------------------------------------------------------
		
        setVisible(true);
        setResizable(true);
        
        
		}
	
//	private class MingchengAction implements ActionListener{
//		 public void actionPerformed(final ActionEvent e){
//			 for(int i=0;i<table_all.getRowCount();i++){
//				 String code = fundcode.getText().trim();
//		           String names=dowName.getText().trim();
//		           String [] ss = {"��������","��������"};
//		           Object[][] results = getjiansuo(EasyMoneySearch.EasyMoneyName(code,names));
//		           table_select = new JTable(results,ss);
//		           table_select.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
//		   		   scrollPane_2.setViewportView(table_select); 
//			 }
//		 }
//	}
	
	private class RiqiqujianAction implements ActionListener{
		public void actionPerformed (final ActionEvent e){
			
		}
	}
	
//	private class DateAction implements ActionListener{
//		public void actionPerformed(final ActionEvent e){
//           if(faburi.getText().length()!=10){
//        	   JOptionPane.showMessageDialog(null, "���������硰2019-01-28����������ʽ");
//				return;
//           }
//           String code = fundcode.getText().trim();
//           String dates=faburi.getText().trim();
//           String [] ss = {"��������","��������"};
//           Object[][] results = getjiansuo(EasyMoneySearch.EasyMoneyDate(code, dates));
//           table_select = new JTable(results,ss);
//           table_select.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
//   		   scrollPane_2.setViewportView(table_select);   
//		}
//	}
	private void fundCols(JTable table){
		TableColumn col_1 = table.getColumnModel().getColumn(0);
		TableColumn col_2 = table.getColumnModel().getColumn(1);
		TableColumn col_3 = table.getColumnModel().getColumn(2);
		col_1.setPreferredWidth(100);
		col_2.setPreferredWidth(280);
		col_3.setPreferredWidth(70);
	}
	
	private DefaultTableModel fundModel(List list){
		String[] fund = {"������","��������","��������"};
		Object[][] funds = getselectF(list);
		DefaultTableModel tableModel = new DefaultTableModel(funds,fund);
	    return tableModel;
	}
	
	private DefaultTableModel gongModel(List list){
		String[] fund = {"","��������","������ҳ","����PDF","��������"};
		Object[][] funds = getselect(list);
		DefaultTableModel tableModel = new DefaultTableModel(funds,fund);
	    return tableModel;
	}
	
	private void gongmodel(JTable table,List list){
		String[] fund = {"��������","����PDF","��������","ȫѡ"};
		Object[][] funds=getselect(list);
		 TableModelProxy tableModel = new TableModelProxy(fund, funds);
	        table.setModel(tableModel);
	        table.getTableHeader().setDefaultRenderer(new CheckHeaderCellRenderer(table));
	        JTableHeader tableHeader = table.getTableHeader();
	        tableHeader.addMouseListener(new MouseAdapter() {
	            public void mouseClicked(MouseEvent e) {
	            	String Name="";
	    			String Path="";
	    			int rows = table_all.getRowCount();
	    			for(int i=0;i<rows;i++){
	    				if(table_all.getValueAt(i,3).toString().equals("true")){
	    					Name = Name+table_all.getValueAt(i, 0).toString().trim()+".pdf;";
	    				    Path = Path+table_all.getValueAt(i, 1).toString().trim()+";";
	    				}
	    			}
	    			System.out.println(Name);
	    			System.out.println(Path);
	    			dowpath.setText(Path);
	    			dowName.setText(Name);
	            }
	        });
	}
	
	private void AllColumnModel(JTable table){
		TableColumn col_1 = table.getColumnModel().getColumn(0);
		TableColumn col_2 = table.getColumnModel().getColumn(1);
		TableColumn col_3 = table.getColumnModel().getColumn(2);
		TableColumn col_4 = table.getColumnModel().getColumn(3);
//		TableColumn col_5 = table.getColumnModel().getColumn(4);
		col_1.setPreferredWidth(280);
		col_2.setPreferredWidth(380);
		col_2.setCellEditor(new linkChooserEditor());
		col_3.setPreferredWidth(80);
		
		col_4.setPreferredWidth(60);
//		col_4.setCellEditor(new linkChooserEditor());
//		col_5.setPreferredWidth(60);
		
//		col_1.setCellEditor(new DefaultCellEditor(new JCheckBox()));   
//        col_1.setCellRenderer(new MyTableRenderer()); 
		
	}
	
	private class SearchListener extends KeyAdapter{
		public void keyTyped(KeyEvent e) {
			
			if (e.getKeyChar() == '\n') { // �ж����ı����Ƿ�����س���
//				if (fundcode.getText().length()!=0){
//					JOptionPane.showMessageDialog(null, "����Ҫ���ݻ����Ų�ѯ����������ȷ����λ������"+"\r\n"
//				+"����Ҫ���ݻ��𹫸����Ʋ�ѯ��������Ҫ��ѯ�Ĺؼ��ּ���"+"\r\n"+"������ѯ�������������磺�������--2019    ��������--201902    ��������--20190210");
//					return;
//				}
				String name=(String)choice.getSelectedItem();
				
				if(name.equals("������")){
				String [] select={"��������","������ҳ","����pdf","��������"};
        		String code = fundcode.getText().trim();
        		List list = DAO.selectPdfCode(code);
        		Object[][] results=getselect(list);

        		table_all = new JTable(results,select);

//        		TableColumn col_1 =  table_all.getColumn("��������");
//        		col_1.setPreferredWidth(50);
//        		TableColumn col_2 =  table_all.getColumn("������ҳ");
//        		col_2.setPreferredWidth(100);
//        		TableColumn col_3 = table_all.getColumn("����pdf");
//        		col_3.setPreferredWidth(100);
//        		TableColumn col_4 = table_all.getColumn("��������");
//        		col_4.setPreferredWidth(30);
        		
        		table_all.addMouseListener(new TableListener());
        		table_all.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        		
        		
        		scrollPane_1.setViewportView(table_all);
			  }
				else if(name.equals("��������ģ����ѯ")){
					String [] select={"��������","������ҳ","����pdf","��������"};
	        		String code = fundcode.getText().trim();
	        		List list = DAO.selectPdfName(code);
	        		Object[][] results=getselect(list);

	        		table_all = new JTable(results,select);
	        		table_all.addMouseListener(new TableListener());
	        		table_all.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
	        		scrollPane_1.setViewportView(table_all);
				}
				else if(name.contains("���淢��")){
					String [] select={"��������","������ҳ","����pdf","��������"};
	        		String code = fundcode.getText().trim();
	        		List list = DAO.selectPdfDate(code);
	        		Object[][] results=getselect(list);

	        		table_all = new JTable(results,select);
	        		table_all.addMouseListener(new TableListener());
	        		table_all.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
	        		scrollPane_1.setViewportView(table_all);
				}
			}
		}
	}
	

	
	private class TableListener extends MouseAdapter {
		public void mouseClicked(final MouseEvent e) {
			int selRow = table_all.getSelectedRow();
			boolean value = !(boolean) table_all.getValueAt(selRow, 3) ;
			table_all.setValueAt(value, selRow, 3);
			String Name="";
			String Path="";
			int rows = table_all.getRowCount();
			for(int i=0;i<rows;i++){
				if(table_all.getValueAt(i,3).toString().equals("true")){
					Name = Name+table_all.getValueAt(i, 0).toString().trim()+".pdf;";
				    Path = Path+table_all.getValueAt(i, 1).toString().trim()+";";
				}
			}
			System.out.println(Name);
			System.out.println(Path);
			
//			for(int i=0;i<selRow.length;i++){
//				
//			Name = table_all.getValueAt(i, 1).toString().trim()+";";
////			System.out.println(Name);
//			Path = table_all.getValueAt(i, 2).toString().trim()+";";
//			}
			dowpath.setText(Path);
			dowName.setText(Name);
		}
	}
	
	
	private class MyTableRenderer extends JCheckBox implements TableCellRenderer {   
	    //�˷������Բ鿼JDK�ĵ���˵��   
	    public Component getTableCellRendererComponent( JTable table,   
	            Object value,   
	            boolean isSelected,   
	            boolean hasFocus,   
	            int row,   
	            int column ) {   
	        Boolean b = (Boolean) value;   
	        this.setSelected(b.booleanValue());   
	        return this;   
	    }   
	}  
	
	private class AllDownAction implements ActionListener{
        public void actionPerformed(final ActionEvent e){
        	String savename;
        	String savepath;
        	String downpath;
        	
        	for(int i=0;i<table_all.getRowCount();i++){
            	if(savePath.getText().trim().equals(defaultpath)){
            		savepath=defaultpath;
            	}else{
            		savepath=savePath.getText().trim();
            	}
            	savename = table_all.getValueAt(i, 0).toString().trim()+".pdf";
				savename=savename.replaceAll("/", "-");
            	if(savename.contains("/"))
					savename.replaceAll("/", "-s");
            	downpath = table_all.getValueAt(i, 1).toString().trim();
            	
            	try {
					DownloadPdf.downLoadByUrl(downpath, savename, savepath);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
            	
            }
        	JOptionPane.showMessageDialog(null, "ȫ�������������");
			return;
       
        }
	}
	
	private class DownloadAction implements ActionListener{
		public void actionPerformed(final ActionEvent e){
			String savepath;
	        if(savePath.getText().trim().equals(defaultpath)){
	        	savepath = defaultpath;
	        }else{
	        	savepath = savePath.getText().trim();
	        }
			String downPath,savename;
			String[] paths = dowpath.getText().trim().split(";");
			String[] names = dowName.getText().trim().split(";");
			try {
				for(int i=0;i<paths.length;i++){
					for(int j=0;j<names.length;j++){
						downPath=paths[i];
						savename=names[j];
				        DownloadPdf.downLoadByUrl(downPath, savename, savepath);
         				}   
					}
				       JOptionPane.showMessageDialog(null, "�������");
						return;
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
						System.out.println("δ�ܳɹ�����");
					}
				
			
			
			
		}
	}
	
	
	
	
	private class CloseActionListener implements ActionListener {			// ���ӹرհ�ť���¼�������
		public void actionPerformed(final ActionEvent e) {
//			doDefaultCloseAction();
			System.exit(0);
		}
	}

	
	public static String replaceSpace(String str){
        StringBuffer sb = new StringBuffer(str);
        
        int length = sb.length();
        
        for(int i=0;i<length;i++){
            if(sb.charAt(i) == ' '){
            	
                sb.setCharAt(i, '%');
                
            }
        }
        return sb.toString();
    }

	
	
	private class linkChooserEditor extends AbstractCellEditor implements TableCellEditor {
		javax.swing.JLabel link = new javax.swing.JLabel();
		Cursor cursor1 = new Cursor(Cursor.HAND_CURSOR);
		Cursor cursor2 = new Cursor(Cursor.DEFAULT_CURSOR);

		public linkChooserEditor(){
		link.setCursor(cursor2);
		link.addMouseListener(new MouseListener(){

		@Override
		public void mouseClicked(MouseEvent e) {
		try {
		java.lang.Runtime.getRuntime().exec("explorer "+link.getText());
//			java.lang.Runtime.getRuntime().exec(link.getText());
		System.out.println(link.getText());
		} catch (Exception ef) {
		;
		}
		}

		@Override
		public void mouseEntered(MouseEvent e) {
		link.setCursor(cursor1);
		}

		@Override
		public void mouseExited(MouseEvent e) {
		link.setCursor(cursor2);
		}

		@Override
		public void mousePressed(MouseEvent e) {

		}

		@Override
		public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

		}

		});
		}
		@Override
		public Component getTableCellEditorComponent(JTable table, Object value,
		boolean isSelected, int row, int column) {
		// TODO Auto-generated method stub
		link.setText(value == null ? "" : value.toString());
		return link;
		}

		@Override
		public Object getCellEditorValue() {
		// TODO Auto-generated method stub
		return link.getText();
		}
	}
	
//	public class TableModelProxy extends AbstractTableModel {
//
//	    /**
//	     * 
//	     */
//	    private static final long serialVersionUID = -3295581072864170310L;
//	    private String[] columnNames;
//
//	    public void setColumnNames(String[] columnNames) {
//	        this.columnNames = columnNames;
//	    }
//
//
//	    public void setData(Object[][] data) {
//	        this.data = data;
//	    }
//
//	    private Object[][] data;
//
//	    public TableModelProxy(String[] columnNames, Object[][] data) {
//	        // TODO Auto-generated constructor stub
//	        this.columnNames = columnNames;
//	        this.data = data;
//	    }
//
//
//	    public String getColumnName(int column) {
//	        // TODO Auto-generated method stub
//	        return columnNames[column];
//	    }
//
//
//	    public Class<?> getColumnClass(int columnIndex) {
//	        // TODO Auto-generated method stub
//	        return getValueAt(0, columnIndex).getClass();
//	    }
//
//
//	    public boolean isCellEditable(int rowIndex, int columnIndex) {
//	        // TODO Auto-generated method stub
//	        // Only the last column can be edit.
//	        if(rowIndex < columnNames.length - 1){
//	            return false;
//	        }else{
//	            return true;
//	        }
//	    }
//
//
//	    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
//	        // TODO Auto-generated method stub
//	        data[rowIndex][columnIndex] = aValue;
//	        fireTableCellUpdated(rowIndex, columnIndex);
//	    }
//
//
//	    public int getRowCount() {
//	        // TODO Auto-generated method stub
//	        return data.length;
//	    }
//
//	    public int getColumnCount() {
//	        // TODO Auto-generated method stub
//	        return columnNames.length;
//	    }
//
//	    public Object getValueAt(int rowIndex, int columnIndex) {
//	        // TODO Auto-generated method stub
//	        return data[rowIndex][columnIndex];
//	    }
//
//	    public void selectAllOrNull(boolean value){
//	        // Select All. The last column
//	        for(int index = 0; index < getRowCount(); index ++){
//	            this.setValueAt(value, index, getColumnCount() - 1);
//	        }
//	    }
//	}
//	
//	public class CheckHeaderCellRenderer implements TableCellRenderer {
//	    TableModelProxy tableModel;
//	    JTableHeader tableHeader;
//	    final JCheckBox selectBox;
//
//	    public CheckHeaderCellRenderer(final JTable table) {
//	        this.tableModel = (TableModelProxy) table.getModel();
//	        this.tableHeader = table.getTableHeader();
//	        selectBox = new JCheckBox(tableModel.getColumnName(table.getColumnCount() - 1));
//	        selectBox.setSelected(false);
//	        tableHeader.addMouseListener(new MouseAdapter() {
//	            public void mouseClicked(MouseEvent e) {
//	                if (e.getClickCount() > 0) {
//	                    // ���ѡ����
//	                    int selectColumn = tableHeader.columnAtPoint(e.getPoint());
//	                    if (selectColumn == table.getColumnCount() - 1) {
//	                        boolean value = !selectBox.isSelected();
//	                        selectBox.setSelected(value);
//	                        tableModel.selectAllOrNull(value);
//	                        tableHeader.repaint();
//	                    }
//	                }
//	            }
//	        });
//	    }
//
//	    @Override
//	    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
//	            int row, int column) {
//	        // TODO Auto-generated method stub
//	        String valueStr = (String) value;
//	        JLabel label = new JLabel(valueStr);
//	        label.setHorizontalAlignment(SwingConstants.CENTER); // ��ͷ��ǩ����
//	        selectBox.setHorizontalAlignment(SwingConstants.CENTER);// ��ͷ��ǩ����
//	        selectBox.setBorderPainted(true);
//	        JComponent component = (column == table.getColumnCount() - 1) ? selectBox : label;
//
//	        component.setForeground(tableHeader.getForeground());
//	        component.setBackground(tableHeader.getBackground());
//	        component.setFont(tableHeader.getFont());
//	        component.setBorder(UIManager.getBorder("TableHeader.cellBorder"));
//
//	        return component;
//	    }
//
//	}


	
	
	public static void main(String[] args){
		new EasyMoneyFrame();
	}
}
