package TEST_1;

public class Fund {

	private String fundCode;
	private String fundName;
	private String fundType;
	
	public Fund(){
		
	}
	
	public Fund(String fundCode,String fundName,String fundCom){
		this.setfundCode(fundCode);
		this.setFundName(fundName);
		this.setFundType(fundType);;
	}
	
	public String getfundCode() {
		return fundCode;
	}
	public void setfundCode(String fundCode) {
		this.fundCode = fundCode;
	}
	public String getFundName() {
		return fundName;
	}
	public void setFundName(String fundName) {
		this.fundName = fundName;
	}


	public String getFundType() {
		return fundType;
	}

	public void setFundType(String fundType) {
		this.fundType = fundType;
	}
	
	
}
