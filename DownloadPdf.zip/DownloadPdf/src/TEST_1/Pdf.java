package TEST_1;

import java.util.ArrayList;
import java.util.List;

public class Pdf {
     
	 private String pdfName;
	 private String pdfId;
	 private String pdfCode;
     private String pdfDownload;
     private String pdfWangye;
     private String pdfDate;
     
     

	public String getPdfDownload() {
		return pdfDownload;
	}

	public void setPdfDownload(String pdfDownload) {
		this.pdfDownload = pdfDownload;
	}

	public String getPdfName() {
		return pdfName;
	}

	public void setPdfName(String pdfName) {
		this.pdfName = pdfName;
	}
     
    public static Object[] [] selectPdf(){
    	List list=new ArrayList();
    	
    	return null;
    }

	public String getPdfDate() {
		return pdfDate;
	}

	public void setPdfDate(String pdfDate) {
		this.pdfDate = pdfDate;
	}

	public String getPdfWangye() {
		return pdfWangye;
	}

	public void setPdfWangye(String pdfWangye) {
		this.pdfWangye = pdfWangye;
	}

	public String getPdfId() {
		return pdfId;
	}

	public void setPdfId(String pdfId) {
		this.pdfId = pdfId;
	}

	public String getPdfCode() {
		return pdfCode;
	}

	public void setPdfCode(String pdfCode) {
		this.pdfCode = pdfCode;
	}
     
     
}
