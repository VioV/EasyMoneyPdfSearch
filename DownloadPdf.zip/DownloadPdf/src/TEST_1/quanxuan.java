package TEST_1;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class quanxuan extends JFrame {

    private JPanel contentPane;
    private JTable table;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    quanxuan frame = new quanxuan();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public quanxuan() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("CheckBox Table");
        this.setPreferredSize(new Dimension(400, 300));
        // setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(new BorderLayout(0, 0));
        setContentPane(contentPane);
        table = new JTable();
        JScrollPane scrollPane = new JScrollPane(table, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        contentPane.add(scrollPane, BorderLayout.CENTER);
        final JTextField text = new JTextField();
//        contentPane.add(text);
        initTable();
        pack();
    }

    private void initTable() {
        String[] columnNames = {"name","age", "choose"};
        Object[][] data = this.getData();
        TableModelProxy tableModel = new TableModelProxy(columnNames, data);
        table.setModel(tableModel);
        table.getTableHeader().setDefaultRenderer(new CheckHeaderCellRenderer(table));
        
    }

    /**
     * �������
     * 
     * @return
     */
    private Object[][] getData() {
        Object[][] data = {
                { "Kathy", 5, new Boolean(false) },
            { "John", 15, new Boolean(true) },
            { "Sue", 16, new Boolean(false) },
            { "Jane",17, new Boolean(true) },
            { "Joe", 18, new Boolean(false) } };
        return data;
    }

}
