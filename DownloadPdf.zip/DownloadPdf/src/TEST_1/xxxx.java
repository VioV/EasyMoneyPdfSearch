package TEST_1;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
public class xxxx
{
 public static void main(String[] args) {
  MyTableFrame myframe=new MyTableFrame();
 }      
}
class MyTableFrame extends JFrame 
{
 JTable table;
 MyTableFrame()
 {
  table=new JTable();
  add(new JScrollPane(initTable(table)));
  setBounds(100,100,500,300);
  setVisible(true);
  validate();
  setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 }
 private JTable initTable(JTable table) {   
        DefaultTableModel dtm = new DefaultTableModel(   
            new Object [] {"","����", "����", "�༶", "�Ա�"},0);   
        dtm.addRow(new Object[] {new Boolean(true),"fox","12","050101","��"});   
           
        table.setModel(dtm);   
        TableColumnModel tcm = table.getColumnModel();   
  
        tcm.getColumn(0).setCellEditor(new DefaultCellEditor(new JCheckBox()));   
        tcm.getColumn(0).setCellRenderer(new MyTableRenderer());   
  
        tcm.getColumn(0).setPreferredWidth(20);   
        tcm.getColumn(0).setWidth(20);   
        tcm.getColumn(0).setMaxWidth(20);   
        return table;   
 }
}
class MyTableRenderer extends JCheckBox implements TableCellRenderer {   
    //�˷������Բ鿼JDK�ĵ���˵��   
    public Component getTableCellRendererComponent( JTable table,   
            Object value,   
            boolean isSelected,   
            boolean hasFocus,   
            int row,   
            int column ) {   
        Boolean b = (Boolean) value;   
        this.setSelected(b.booleanValue());   
        return this;   
    }   
}  