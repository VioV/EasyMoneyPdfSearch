package TEST_1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;



public class DAO {
	protected static String dbClassName = "com.mysql.jdbc.Driver";
	protected static String dbUrl ="jdbc:mysql://rm-aliyunviolet-easymoney.mysql.rds.aliyuncs.com:3306";
	protected static String dbUser = "yonghu";
	protected static String dbPwd = "Easymoney123456";
	private static Connection conn = null;
	
	private  DAO(){
		try{
    		Class.forName(dbClassName);
//    		conn = DriverManager.getConnection(dbUrl);
    		conn=DriverManager.getConnection(dbUrl,dbUser,dbPwd);
System.out.println("�ѽ���database");
    	}catch(ClassNotFoundException e){
    		e.printStackTrace();
    	} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/*
	 * ��ѯ����
	 */
	private static ResultSet executeQuery(String sql) {
		try {
			if(conn==null)
			new DAO();
			Statement stat= conn.createStatement();
			ResultSet rs=stat.executeQuery(sql);
System.out.println("�ɹ�ִ�У�"+sql);
			return rs;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		} finally {
		}
	}
	
	/*
	 * ���²���
	 */
private static int executeUpdate(String sql) {
		
		try {
			if(conn==null)
				new DAO();
			    Statement stat= conn.createStatement();
			    int rs=stat.executeUpdate(sql);
System.out.println("�ɹ�ִ�У�"+sql);
			return rs;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			//if(e.getMessage().equals("[Microsoft][SQLServer 2000 Driver for JDBC][SQLServer]DELETE ����� COLUMN REFERENCE Լ�� 'FK_TB_BORRO_REFERENCE_TB_BOOKI' ��ͻ���ó�ͻ���������ݿ� 'db_library'���� 'tb_borrow', column 'bookISBN'��"))
				
			return -1;
		} finally {
		}
	}

	public static void close() {
		try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			conn = null;
		}
	}
	
/*	public static void main(String[] args){
		DAO dao=new DAO();
//        dao.executeQuery("select c_name from easymoney.company");  
	    dao.selectCompany("�㷢");
	}*/
	
	
	
	/*
	 * �Թ�����ĸ���
	 */
	public static int InsertGonggao(String f_code,String g_name,String g_id){
		int i=0;
		try{
			String sql="insert into easymoney.gonggao(f_code,g_name,g_id)"
					+ "values('"+f_code+"','"+g_name+"','"+g_id+"')";
			i=DAO.executeUpdate(sql);
		}catch(Exception e){
			e.printStackTrace();
		}
		return i;
	}
	
	
	//���ҹ�˾���ƣ����ر���Լ���˾���ƣ�
	public static List selectCompany(String name) {
		List list=new ArrayList();
		String sql = "select * from easymoney.company where c_name like '%"+name+"%'";
		ResultSet rs = DAO.executeQuery(sql);
		try {
			while (rs.next()) {
				Company com=new Company();
				com.setComId(rs.getString("c_id"));
//				System.out.println(pdf.getPdfName().toString());
                com.setComName(rs.getString("c_name"));
//				System.out.println(pdf.getPdfDownload().toString());
				list.add(com);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		DAO.close();
		return list;
	}
	
	//���ҹ�˾��ȫ����Ϣ
	public static List selectCompany(){
		List list = new ArrayList();
		String sql = "select * from easymoney.company";
		ResultSet rs = DAO.executeQuery(sql);
		try{
			while(rs.next()){
				Company com = new Company();
				com.setComId(rs.getString("c_id"));
				com.setComName(rs.getString("c_name"));
				list.add(com);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		DAO.close();
		return list;
	}
	
	//���һ���ȫ��
	public static List selectFundCodeAll() {
		List list=new ArrayList();
		String sql = "select f_code from easymoney.fund";
		ResultSet rs = DAO.executeQuery(sql);
		try {
			while (rs.next()) {
				String code = rs.getString("f_code");
				list.add(code);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		DAO.close();
		return list;
	}
	
	
	//���ҷ������л�����Ϣ
	public static List selectFund(){
		List list = new ArrayList();
		String sql = "select * from easymoney.fund";
		ResultSet rs = DAO.executeQuery(sql);
		try{
			while(rs.next()){
				Fund fund = new Fund();
				fund.setfundCode(rs.getString("f_code"));
				fund.setFundName(rs.getString("f_name"));
				fund.setFundType(rs.getString("f_type"));
				list.add(fund);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		DAO.close();
		return list;
	}
	
	
	//���һ������ƣ����ر�š����������Լ�������˾��
	public static List selectFund(String name) {
		List list=new ArrayList();
		String sql = "select * from easymoney.fund where f_name like '%"+name+"%'";
		ResultSet rs = DAO.executeQuery(sql);
		try {
			while (rs.next()) {
                Fund fund = new Fund();
                fund.setfundCode(rs.getString("f_code"));
                fund.setFundName(rs.getString("f_name"));
                fund.setFundType(rs.getString("f_type"));
				list.add(fund);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		DAO.close();
		return list;
	}

	//���һ����ţ����ػ������Ƽ�������˾)
	public static List selectFundCode(String code) {
		List list=new ArrayList();
		String sql = "select *from easymoney.fund where f_code like '%"+code+"%'";
		ResultSet rs = DAO.executeQuery(sql);
		try {
			while (rs.next()) {
                Fund fund = new Fund();
                fund.setfundCode(rs.getString("f_code"));
                fund.setFundName(rs.getString("f_name"));
                fund.setFundType(rs.getString("f_type"));
				list.add(fund);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		DAO.close();
		return list;
	}
	
	
	//���һ�����������
	public static List selectFundCN(String code,String name){
		List list = new ArrayList();
		String sql = "select * from easymoney.fund where f_code like '%"+code+"'"
		+" and f_name like '%"+name+"%'";
		ResultSet rs = DAO.executeQuery(sql);
		try{
			while (rs.next()) {
                Fund fund = new Fund();
                fund.setfundCode(rs.getString("f_code"));
                fund.setFundName(rs.getString("f_name"));
                fund.setFundType(rs.getString("f_type"));
				list.add(fund);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		DAO.close();
		return list;
	}
	
	
	
	
	//���һ���˾���� �����ػ������Լ��������ƣ�
	public static List selectFundCom(String com) {
		List list=new ArrayList();
		String sql = "select f_code,f_name from easymoney.fund where f_com like '%"+com+"%'";
		ResultSet rs = DAO.executeQuery(sql);
		try {
			while (rs.next()) {
                Fund fund = new Fund();
                fund.setfundCode(rs.getString("f_code"));
                fund.setFundName(rs.getString("f_name"));
//                fund.setFundCom(rs.getString("f_com"));
				list.add(fund);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		DAO.close();
		return list;
	}
	
	
	//�����š��������ơ��������ڣ���Bdate��Edate��
	public static List selectPdfAll(String code,String name,String Bdate,String Edate){
		List list = new ArrayList();
		String sql ="select * from easymoney.gonggao where f_code like '"+code+"'and"
				+" g_name like '%"+name+"%' and g_date between '"+Bdate+"' and '"+Edate+"'";
		ResultSet rs = DAO.executeQuery(sql);
		try {
			while (rs.next()) {
				Pdf pdf=new Pdf();
				pdf.setPdfName(rs.getString("g_name"));
				pdf.setPdfDownload("http://pdf.dfcfw.com/pdf/H2_"+rs.getString("g_id")+"_1.pdf");
				pdf.setPdfWangye("http://fund.eastmoney.com/gonggao/"+rs.getString("f_code")+","+rs.getString("g_id")+".html");
				pdf.setPdfDate(rs.getString("g_date"));
				list.add(pdf);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		DAO.close();
		return list;
	}
	
	//�����š��������ơ��������ڣ���Bdate��Edate��
	public static List selectPdfAll(String code,String name,String Bdate){
		List list = new ArrayList();
		String sql ="select * from easymoney.gonggao where f_code like '"+code+"'and"
				+"g_name like '%"+name+"%' and g_date like '"+Bdate+"'";
		ResultSet rs = DAO.executeQuery(sql);
		try {
			while (rs.next()) {
				Pdf pdf=new Pdf();
				pdf.setPdfName(rs.getString("g_name"));
				pdf.setPdfDownload("http://pdf.dfcfw.com/pdf/H2_"+rs.getString("g_id")+"_1.pdf");
				pdf.setPdfWangye("http://fund.eastmoney.com/gonggao/"+rs.getString("f_code")+","+rs.getString("g_id")+".html");
				pdf.setPdfDate(rs.getString("g_date"));
				list.add(pdf);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		DAO.close();
		return list;
	}
	
	
	//�����š���������
	public static List selectPdfCN(String code,String name){
			List list = new ArrayList();
			String sql ="select * from easymoney.gonggao where f_code like '"+code+"'and"
					+" g_name like '%"+name+"%'";
			ResultSet rs = DAO.executeQuery(sql);
			try {
				while (rs.next()) {
					Pdf pdf=new Pdf();
					pdf.setPdfName(rs.getString("g_name"));
					pdf.setPdfDownload("http://pdf.dfcfw.com/pdf/H2_"+rs.getString("g_id")+"_1.pdf");
					pdf.setPdfWangye("http://fund.eastmoney.com/gonggao/"+rs.getString("f_code")+","+rs.getString("g_id")+".html");
					pdf.setPdfDate(rs.getString("g_date"));
					list.add(pdf);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			DAO.close();
			return list;
	}
	
	//�����š��������ڣ���Bdate��Edate��
	public static List selectPdfCD(String code,String Bdate,String Edate){
		List list = new ArrayList();
		String sql ="select * from easymoney.gonggao where f_code like '"+code+"'and g_date between '"+Bdate+"' and '"+Edate+"'";
		ResultSet rs = DAO.executeQuery(sql);
		try {
			while (rs.next()) {
				Pdf pdf=new Pdf();
				pdf.setPdfName(rs.getString("g_name"));
				pdf.setPdfDownload("http://pdf.dfcfw.com/pdf/H2_"+rs.getString("g_id")+"_1.pdf");
				pdf.setPdfWangye("http://fund.eastmoney.com/gonggao/"+rs.getString("f_code")+","+rs.getString("g_id")+".html");
				pdf.setPdfDate(rs.getString("g_date"));
				list.add(pdf);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		DAO.close();
		return list;
	}
	
	//�����š��������ڣ�ֻ��һ�����ڣ�
	public static List selectPdfCD(String code,String Bdate){
		List list = new ArrayList();
		String sql ="select * from easymoney.gonggao where f_code like '"+code+"' and g_date like '"+Bdate+"'";
		ResultSet rs = DAO.executeQuery(sql);
		try {
			while (rs.next()) {
				Pdf pdf=new Pdf();
				pdf.setPdfName(rs.getString("g_name"));
				pdf.setPdfDownload("http://pdf.dfcfw.com/pdf/H2_"+rs.getString("g_id")+"_1.pdf");
				pdf.setPdfWangye("http://fund.eastmoney.com/gonggao/"+rs.getString("f_code")+","+rs.getString("g_id")+".html");
				pdf.setPdfDate(rs.getString("g_date"));
				list.add(pdf);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		DAO.close();
		return list;
	}
	
	//�������ơ��������ڣ���Bdate��Edate��
	public static List selectPdfND(String name,String Bdate,String Edate){
		List list = new ArrayList();
		String sql ="select * from easymoney.gonggao where g_name like '"+name
				+"' and g_date between '"+Bdate+"' and '"+Edate+"'";
		ResultSet rs = DAO.executeQuery(sql);
		try {
			while (rs.next()) {
				Pdf pdf=new Pdf();
				pdf.setPdfName(rs.getString("g_name"));
				pdf.setPdfDownload("http://pdf.dfcfw.com/pdf/H2_"+rs.getString("g_id")+"_1.pdf");
				pdf.setPdfWangye("http://fund.eastmoney.com/gonggao/"+rs.getString("f_code")+","+rs.getString("g_id")+".html");
				pdf.setPdfDate(rs.getString("g_date"));
				list.add(pdf);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		DAO.close();
		return list;
	}
	
	//�������ơ��������ڣ�ֻ��һ�����ڣ�
	public static List selectPdfND(String name,String Bdate){
		List list = new ArrayList();
		String sql ="select * from easymoney.gonggao where g_name like '%"+name+"%' and g_date like'"+Bdate+"'";
		ResultSet rs = DAO.executeQuery(sql);
		try {
			while (rs.next()) {
				Pdf pdf=new Pdf();
				pdf.setPdfName(rs.getString("g_name"));
				pdf.setPdfDownload("http://pdf.dfcfw.com/pdf/H2_"+rs.getString("g_id")+"_1.pdf");
				pdf.setPdfWangye("http://fund.eastmoney.com/gonggao/"+rs.getString("f_code")+","+rs.getString("g_id")+".html");
				pdf.setPdfDate(rs.getString("g_date"));
				list.add(pdf);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		DAO.close();
		return list;
	}
	
	
	//���ҹ�������ţ����ع������ƣ����������Լ���������
	public static List selectPdfCode(String code) {
		List list=new ArrayList();
		String sql = "select * from easymoney.gonggao where f_code like '"+code+"'";
		ResultSet rs = DAO.executeQuery(sql);
		try {
			while (rs.next()) {
				Pdf pdf=new Pdf();
				pdf.setPdfName(rs.getString("g_name"));
				pdf.setPdfDownload("http://pdf.dfcfw.com/pdf/H2_"+rs.getString("g_id")+"_1.pdf");
				pdf.setPdfWangye("http://fund.eastmoney.com/gonggao/"+rs.getString("f_code")+","+rs.getString("g_id")+".html");
				pdf.setPdfDate(rs.getString("g_date"));
				list.add(pdf);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		DAO.close();
		return list;
	}
	
	
	//���ҹ������ƣ����ع������ƣ����������Լ����ӣ�
	public static List selectPdfName(String name) {
		List list=new ArrayList();
		String sql = "select * from easymoney.gonggao where g_name like '%"+name+"%'";
		ResultSet rs = DAO.executeQuery(sql);
		try {
			while (rs.next()) {
				Pdf pdf=new Pdf();
				pdf.setPdfName(rs.getString("g_name"));
				pdf.setPdfDownload("http://pdf.dfcfw.com/pdf/H2_"+rs.getString("g_id")+"_1.pdf");
				pdf.setPdfWangye("http://fund.eastmoney.com/gonggao/"+rs.getString("f_code")+","+rs.getString("g_id")+".html");
				pdf.setPdfDate(rs.getString("g_date"));
				list.add(pdf);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		DAO.close();
		return list;
	}
	
	//���ҹ�����������
	public static List selectPdfDatequjian(String Bdate,String Edate){
		List list = new ArrayList();
		String sql ="select * from easymoney.gonggao where g_date between '"+Bdate+"' and '"+Edate+"'";
		ResultSet rs = DAO.executeQuery(sql);
		try {
			while (rs.next()) {
				Pdf pdf=new Pdf();
				pdf.setPdfName(rs.getString("g_name"));
				pdf.setPdfDownload("http://pdf.dfcfw.com/pdf/H2_"+rs.getString("g_id")+"_1.pdf");
				pdf.setPdfWangye("http://fund.eastmoney.com/gonggao/"+rs.getString("f_code")+","+rs.getString("g_id")+".html");
				pdf.setPdfDate(rs.getString("g_date"));
				list.add(pdf);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		DAO.close();
		return list;
	}
	
	//���ҹ������ڣ�ֻ��һ�����ڣ�
	public static List selectPdfDate(String date) {
		List list=new ArrayList();
		String sql = "select * from easymoney.gonggao where g_date like '"+date+"'";
		ResultSet rs = DAO.executeQuery(sql);
		try {
			while (rs.next()) {
				Pdf pdf=new Pdf();
				pdf.setPdfName(rs.getString("g_name"));
				pdf.setPdfDownload("http://pdf.dfcfw.com/pdf/H2_"+rs.getString("g_id")+"_1.pdf");
				pdf.setPdfWangye("http://fund.eastmoney.com/gonggao/"+rs.getString("f_code")+","+rs.getString("g_id")+".html");
				pdf.setPdfDate(rs.getString("g_date"));
				list.add(pdf);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		DAO.close();
		return list;
	}
	
	
}
