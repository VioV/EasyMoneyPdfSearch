package TEST_1;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.AbstractCellEditor;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableColumn;

public class xxxxxx {

private JTable table;
private JFrame frame;

/**
 * Launch the application
 * @param args
 */
public static void main(String args[]) {
try {
xxxxxx window = new xxxxxx();
window.frame.setVisible(true);
} catch (Exception e) {
e.printStackTrace();
}
}

/**
 * Create the application
 */
public xxxxxx() {
initialize();
}

/**
 * Initialize the contents of the frame
 */
private void initialize() {
frame = new JFrame();
frame.setBounds(100, 100, 500, 375);
frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

final JScrollPane scrollPane = new JScrollPane();
frame.getContentPane().add(scrollPane, BorderLayout.CENTER);

table = new JTable(1,2);
scrollPane.setViewportView(table);
TableColumn column = table.getColumnModel().getColumn(0);
table.setValueAt("http://www.baidu.com", 0, 0);
column.setCellEditor(new linkChooserEditor());
}

}

class linkChooserEditor extends AbstractCellEditor implements TableCellEditor {
javax.swing.JLabel link = new javax.swing.JLabel();
Cursor cursor1 = new Cursor(Cursor.HAND_CURSOR);
Cursor cursor2 = new Cursor(Cursor.DEFAULT_CURSOR);

public linkChooserEditor(){
link.setCursor(cursor2);
link.addMouseListener(new MouseListener(){

@Override
public void mouseClicked(MouseEvent e) {
try {
java.lang.Runtime.getRuntime().exec("explorer "+link.getText());
} catch (Exception ef) {
;
}
}

@Override
public void mouseEntered(MouseEvent e) {
link.setCursor(cursor1);
}

@Override
public void mouseExited(MouseEvent e) {
link.setCursor(cursor2);
}

@Override
public void mousePressed(MouseEvent e) {

}

@Override
public void mouseReleased(MouseEvent e) {
// TODO Auto-generated method stub

}

});
}
@Override
public Component getTableCellEditorComponent(JTable table, Object value,
boolean isSelected, int row, int column) {
// TODO Auto-generated method stub
link.setText(value == null ? "" : value.toString());
return link;
}

@Override
public Object getCellEditorValue() {
// TODO Auto-generated method stub
return link.getText();
}

} 