package TEST_1;

public class test4check {
	static boolean b1,b2,b3;
	private static void test4check(boolean x,boolean y,boolean z){
		b1=x;
		b2=y;
		b3=z;
		if(b1==true&&b2==true&&b3==true){
			System.out.println("ȫѡ");
		}else if(b1==true&&b2==true&&b3==false){
			System.out.println("ѡ��b1��b2��û��ѡ��b3");
		}else if(b1==true&&b2==false&&b3==false){
			System.out.println("ֻѡ����b1");
		}else if(b1==false&&b2==false&&b3==false){
			System.out.println("����ѡ");
		}else if(b1==false&&b2==false&&b3==true){
			System.out.println("ֻѡ����b3");
		}else if(b1==false&&b2==true&&b3==false){
			System.out.println("ֻѡ����b2");
		}else if(b1==false&&b2==true&&b3==true){
			System.out.println("ѡ����b2��b3��û��ѡ��b1");
		}else if(b1==true&&b2==false&&b3==true){
			System.out.println("ѡ����b1��b3��û��ѡ��b2");
		}
		
	}
	
	
	
public static String replaceSpace(String str){
        StringBuffer sb = new StringBuffer(str);
        
        int length = sb.length();
        
        for(int i=0;i<length;i++){
            if(sb.charAt(i) == ' '){
            	
                sb.setCharAt(i, '%');
                
            }
        }
        return sb.toString();
    }
	
    public static void main(String[] args){
//    	test4check(true,true,true);
//    	test4check(true,true,false);
//    	test4check(true,false,true);
//    	test4check(true,false,false);
//    	test4check(false,true,true);
//    	test4check(false,false,true);
//    	test4check(false,true,false);
//    	test4check(false,false,false);
    	String url = "xxx.html";
    	String[] urls = url.split(";");
    	for (int i = 0;i<urls.length;i++){
    		System.out.println(urls.length);
    		System.out.println(urls[i].toString());
    	}
    }
	
    
}
