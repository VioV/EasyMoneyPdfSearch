package TEST_1;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

public class EasyMoneyUpdate {
	 private static String path="http://api.fund.eastmoney.com/f10/JJGG?callback=jQuery18306859616264924178&fundcode=";
	 private static String text_1="&pageIndex=";
	 private static String text_2="&pageSize=20&type=0&_=";
	 
	 public static void AllUpdate(String fundcode){
    	 for(int page=1;page<100;page++){
           String pages=page+"";   
    	   CloseableHttpClient client = HttpClients.createDefault();
		   HttpGet getData = new HttpGet(path+fundcode+text_1+pages+text_2+new Date().getTime());
		   getData.setHeader("Host", "api.fund.eastmoney.com");
		   getData.setHeader("Referer", "http://fundf10.eastmoney.com/jjgg_"+fundcode+".html");
		   try {
			   HttpResponse response = client.execute(getData);
			   String result1 = EntityUtils.toString(response.getEntity());
			   result1 = result1.substring(result1.indexOf("(")+1, result1.length()-1);
			   JSONObject jsonObject = new JSONObject(result1);
			   JSONArray data = jsonObject.getJSONArray("Data");
			   JSONObject d = null;
			   int x = data.length();
			   for(int i = 0 ;i<data.length();i++){
				   d = new JSONObject(data.get(i).toString());
				   String g_name = d.get("TITLE").toString();
				   String g_id = d.get("ID").toString();
				   String g_date = d.get("PUBLISHDATE").toString();
                   DAO.InsertGonggao(fundcode, g_name, g_id);		   
				 /*  Pdf pdf = new Pdf();
				   pdf.setPdfDate(d.get("PUBLISHDATE").toString());
				   pdf.setPdfName(d.get("TITLE").toString());
				   pdf.setPdfCode(d.get("FUNDCODE").toString());
				   pdf.setPdfId(d.get("ID").toString());
				   */
//				   pdf.setPdfDownload("http://pdf.dfcfw.com/pdf/H2_"+d.get("ID").toString()+"_1.pdf");
//				   list.add(pdf);
				   String pdfPath =d.get("FUNDCODE")+"\r\n"+d.get("TITLE")+"\r\n"+"http://pdf.dfcfw.com/pdf/H2_"+d.get("ID")+"_1.pdf";
				   System.out.println(pdfPath);
			       
			   }
			   if(x==0)
                  break;
		       System.out.println("---------page="+pages+"--------");
		   } catch (ClientProtocolException e) {
			   // TODO Auto-generated catch block
			   e.printStackTrace();
		   } catch (IOException e) {
			   // TODO Auto-generated catch block
			   e.printStackTrace();
		   }finally{
			   try {
				client.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   }
		  
		   }
//		return list;
	}
	 
	 public static void XunhuanCode(){
		 List list=DAO.selectFundCodeAll();
		 for(int i=0;i<list.size();i++){
			 String code = list.get(i).toString();
			 try {
			     int b = Integer.valueOf(code).intValue();
				 if(b==960042){
					 System.out.println("------");
					 EasyMoneyUpdate.AllUpdate(code);
				     
				 }
			 } catch (NumberFormatException e) {
			     e.printStackTrace();
			 }
			 
		
			 
//			 EasyMoneyUpdate.AllUpdate(code);
		 }
	 }
	 
	 public static void main(String[] args){
//          DAO.InsertGonggao("000001", "test2", "AN201902080000000900");
		 		 XunhuanCode();
	 }
}
