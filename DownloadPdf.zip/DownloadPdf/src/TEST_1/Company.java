package TEST_1;

public class Company {
    
	private String comId;
	private String comName;
	
	public Company(){
		
	}
	
	public Company(String comId,String comName){
		this.setComId(comId);
		this.setComName(comName);
	}
	
	public String getComId() {
		return comId;
	}
	public void setComId(String comId) {
		this.comId = comId;
	}
	public String getComName() {
		return comName;
	}
	public void setComName(String comName) {
		this.comName = comName;
	}
	
	
}
